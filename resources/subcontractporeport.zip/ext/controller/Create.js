sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";return{Create:function(s,n){e.show("Custom handler invoked.")}}});
//# sourceMappingURL=Create.js.map